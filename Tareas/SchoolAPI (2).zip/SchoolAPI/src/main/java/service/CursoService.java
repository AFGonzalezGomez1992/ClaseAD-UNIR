package service;

import model.Curso;


public interface CursoService {
    Curso getCursoPorAula(int aulaId);
}