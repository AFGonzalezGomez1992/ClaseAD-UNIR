package database;

public interface SchemaDB {
    String user = "andresfgonzalezgomez";
    String pass = "HZmsldBL2hoHaOWq";
}
