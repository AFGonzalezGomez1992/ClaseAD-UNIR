package com.example.LigasAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LigasApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LigasApiApplication.class, args);
	}

}
